﻿using System.Threading.Tasks;

namespace BancoDataCoper
{
    public interface IDataService
    {
        Task InicializaDB();
    }
}